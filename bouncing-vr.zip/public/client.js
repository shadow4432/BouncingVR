const socket = io();
console.log("Client connected");
